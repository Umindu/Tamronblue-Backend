from django.contrib import admin
from .models import Land

# Register your models here.
admin.site.register(Land)