from django.apps import AppConfig


class GrnConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'grn'
