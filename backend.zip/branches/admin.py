from django.contrib import admin
from branches.models import Branch

# Register your models here.
admin.site.register(Branch)