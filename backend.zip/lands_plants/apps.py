from django.apps import AppConfig


class LandsPlantsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lands_plants'
