from django.contrib import admin
from .models import LandPlant

# Register your models here.
admin.site.register(LandPlant)