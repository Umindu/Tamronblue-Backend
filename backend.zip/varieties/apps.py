from django.apps import AppConfig


class VarietiesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'varieties'
