from django.contrib import admin
from .models import Variety

# Register your models here.
admin.site.register(Variety)