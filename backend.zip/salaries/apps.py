from django.apps import AppConfig


class SalariesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'salaries'
