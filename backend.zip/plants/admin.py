from django.contrib import admin
from .models import Plant

# Register your models here.

admin.site.register(Plant)